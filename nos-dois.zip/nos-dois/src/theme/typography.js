// Tipografia — fontes do sistema (mais rápido, sem download).
// Tamanho mínimo 16 conforme diretriz de acessibilidade.
import { Platform } from 'react-native';

const fontFamily = Platform.select({
  ios: 'Georgia',          // serif acolhedora no iOS
  android: 'serif',        // serif do sistema Android
  default: 'serif',
});

const sansFamily = Platform.select({
  ios: 'System',
  android: 'sans-serif',
  default: 'sans-serif',
});

export const typography = {
  // Títulos com serifa pra dar calor
  displayLarge: {
    fontFamily,
    fontSize: 32,
    lineHeight: 40,
    fontWeight: '600',
  },
  displayMedium: {
    fontFamily,
    fontSize: 26,
    lineHeight: 34,
    fontWeight: '600',
  },
  heading: {
    fontFamily,
    fontSize: 22,
    lineHeight: 30,
    fontWeight: '600',
  },

  // Corpo em sans pra legibilidade
  bodyLarge: {
    fontFamily: sansFamily,
    fontSize: 18,
    lineHeight: 26,
    fontWeight: '400',
  },
  bodyMedium: {
    fontFamily: sansFamily,
    fontSize: 16,           // mínimo acessível
    lineHeight: 24,
    fontWeight: '400',
  },
  bodySmall: {
    fontFamily: sansFamily,
    fontSize: 14,
    lineHeight: 20,
    fontWeight: '400',
  },
  label: {
    fontFamily: sansFamily,
    fontSize: 16,
    lineHeight: 22,
    fontWeight: '600',
  },
  caption: {
    fontFamily: sansFamily,
    fontSize: 13,
    lineHeight: 18,
    fontWeight: '400',
  },
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const radii = {
  sm: 8,
  md: 12,
  lg: 20,
  xl: 28,
  pill: 999,
};
