// Paleta "Nós Dois" — tons suaves, contraste adequado para acessibilidade
export const colors = {
  // Fundos
  background: '#FAF3EE',      // bege quase branco — fundo principal
  surface: '#FFFFFF',         // cards
  surfaceMuted: '#F2E6DD',    // cards secundários, placeholders

  // Acento (rosé)
  primary: '#C97B6A',         // rosé queimado — botão principal, contraste AA com branco
  primarySoft: '#E8B5A8',     // rosé claro — estados hover/disabled
  primaryWash: '#F7E4DD',     // rosé bem clarinho — fundo de cards destacados

  // Texto
  textPrimary: '#3D2B26',     // marrom profundo, mais quente que preto puro
  textSecondary: '#7A6660',   // marrom suave para textos auxiliares
  textMuted: '#A89690',       // muito suave — placeholders, dicas

  // Bordas e divisores
  border: '#EADBD1',
  divider: '#F0E3D8',

  // Estados (suaves, nunca agressivos)
  success: '#7BA787',
  successWash: '#E5EFE7',
  error: '#C26D6D',           // erro suave — sem vermelho gritante
  errorWash: '#F5E2E2',
};
