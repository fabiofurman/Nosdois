import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { getProfile, saveProfile as saveProfileStorage, isOnboarded } from '../storage/storage';

const ProfileContext = createContext(null);

export function ProfileProvider({ children }) {
  const [profile, setProfile] = useState(null);
  const [onboarded, setOnboarded] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const [p, ob] = await Promise.all([getProfile(), isOnboarded()]);
      setProfile(p);
      setOnboarded(ob);
      setLoading(false);
    })();
  }, []);

  const completeOnboarding = useCallback(async ({ userName, partnerName }) => {
    const saved = await saveProfileStorage({ userName, partnerName });
    setProfile(saved);
    setOnboarded(true);
  }, []);

  return (
    <ProfileContext.Provider
      value={{ profile, onboarded, loading, completeOnboarding }}
    >
      {children}
    </ProfileContext.Provider>
  );
}

export function useProfile() {
  const ctx = useContext(ProfileContext);
  if (!ctx) {
    throw new Error('useProfile precisa estar dentro de <ProfileProvider>');
  }
  return ctx;
}
