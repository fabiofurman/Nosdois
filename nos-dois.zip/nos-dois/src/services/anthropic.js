/**
 * Cliente da API Anthropic.
 *
 * ⚠️ AVISO DE SEGURANÇA:
 * Esta implementação chama a API direto do app, com a chave embutida via
 * EXPO_PUBLIC_ANTHROPIC_API_KEY. Isso é ACEITÁVEL para desenvolvimento e
 * uso pessoal, mas NÃO É SEGURO em produção pública: qualquer pessoa que
 * inspecionar o tráfego do app extrai a chave. Para distribuir, mova esta
 * chamada pra um backend (Cloudflare Worker, Supabase Edge Function, etc.)
 * — basta trocar a URL e remover o header da chave.
 *
 * Modelo padrão: Haiku 4.5 (rápido e barato — ótimo pra reformulação curta).
 * Para qualidade máxima, troque para 'claude-sonnet-4-6'.
 */

const API_URL = 'https://api.anthropic.com/v1/messages';
const MODEL = 'claude-haiku-4-5-20251001';
const MAX_TOKENS = 400;

const SYSTEM_PROMPT = `Você é um assistente especializado em Comunicação Não-Violenta (CNV) para casais. Sua função é reformular mensagens escritas no impulso — com raiva, mágoa ou frustração — transformando-as em comunicação respeitosa, empática e clara.

Use sempre a estrutura: "Eu me sinto [emoção] quando [situação], e gostaria [pedido]."

Mantenha o sentimento original, mas elimine acusações, generalizações ("nunca", "sempre") e linguagem agressiva. Seja humano, acolhedor e breve.

Responda APENAS com a mensagem reformulada, sem explicações, introduções ou comentários adicionais.

Idioma: Português Brasileiro.`;

/**
 * Reformula uma mensagem usando a API da Anthropic.
 * @param {string} originalMessage - texto bruto do usuário
 * @param {string} apiKey - chave da Anthropic (sk-ant-...)
 * @returns {Promise<string>} - mensagem reformulada
 */
export async function reformulateMessage(originalMessage, apiKey) {
  if (!apiKey || !apiKey.startsWith('sk-ant-')) {
    throw new Error(
      'Chave da API não configurada. Veja o README pra como adicionar a sua chave.'
    );
  }

  const trimmed = (originalMessage || '').trim();
  if (!trimmed) {
    throw new Error('Escreva uma mensagem antes de reformular.');
  }

  let response;
  try {
    response = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
        // Necessário para chamadas direto do navegador/app móvel
        'anthropic-dangerous-direct-browser-access': 'true',
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: MAX_TOKENS,
        system: SYSTEM_PROMPT,
        messages: [
          {
            role: 'user',
            content: trimmed,
          },
        ],
      }),
    });
  } catch (networkErr) {
    throw new Error(
      'Não consegui conectar. Verifique sua internet e tente de novo.'
    );
  }

  if (!response.ok) {
    let detail = '';
    try {
      const errBody = await response.json();
      detail = errBody?.error?.message || '';
    } catch {
      // ignora
    }
    if (response.status === 401) {
      throw new Error('Chave da API inválida. Confira no console.anthropic.com.');
    }
    if (response.status === 429) {
      throw new Error('Muitas requisições agora. Aguarde um instante e tente de novo.');
    }
    throw new Error(
      `A IA não respondeu como esperado (status ${response.status}). ${detail}`.trim()
    );
  }

  const data = await response.json();

  // A resposta vem como array de blocos; pegamos só os de texto.
  const text = (data?.content || [])
    .filter((block) => block.type === 'text')
    .map((block) => block.text)
    .join('\n')
    .trim();

  if (!text) {
    throw new Error('A IA retornou vazio. Tente de novo.');
  }

  return text;
}
