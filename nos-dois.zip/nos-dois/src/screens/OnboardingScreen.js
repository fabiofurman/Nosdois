import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
} from 'react-native';
import Button from '../components/Button';
import { colors } from '../theme/colors';
import { typography, spacing, radii } from '../theme/typography';
import { useProfile } from '../context/ProfileContext';

export default function OnboardingScreen() {
  const { completeOnboarding } = useProfile();
  const [step, setStep] = useState(1);
  const [userName, setUserName] = useState('');
  const [partnerName, setPartnerName] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const canAdvanceStep1 = userName.trim().length > 0;
  const canFinish = partnerName.trim().length > 0;

  async function handleFinish() {
    setSubmitting(true);
    try {
      await completeOnboarding({ userName, partnerName });
      // O ProfileContext atualiza `onboarded`, o RootNavigator troca de stack.
    } catch {
      setSubmitting(false);
    }
  }

  return (
    <SafeAreaView style={styles.safe}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        style={styles.flex}
      >
        <View style={styles.container}>
          <View style={styles.header}>
            <Text style={styles.brand}>Nós Dois</Text>
            <Text style={styles.subtitle}>
              Um espaço pra cuidar do que importa, juntos.
            </Text>
          </View>

          {step === 1 ? (
            <View style={styles.stepBox}>
              <Text style={styles.question}>Como você se chama?</Text>
              <TextInput
                value={userName}
                onChangeText={setUserName}
                placeholder="Seu nome"
                placeholderTextColor={colors.textMuted}
                style={styles.input}
                autoCapitalize="words"
                returnKeyType="next"
                onSubmitEditing={() => canAdvanceStep1 && setStep(2)}
              />
              <Button
                title="Continuar"
                onPress={() => setStep(2)}
                disabled={!canAdvanceStep1}
                style={styles.button}
              />
            </View>
          ) : (
            <View style={styles.stepBox}>
              <Text style={styles.question}>
                E o nome do seu par?
              </Text>
              <TextInput
                value={partnerName}
                onChangeText={setPartnerName}
                placeholder="Nome do parceiro(a)"
                placeholderTextColor={colors.textMuted}
                style={styles.input}
                autoCapitalize="words"
                returnKeyType="done"
                onSubmitEditing={() => canFinish && handleFinish()}
              />
              <Button
                title="Começar"
                onPress={handleFinish}
                disabled={!canFinish}
                loading={submitting}
                style={styles.button}
              />
              <Button
                title="Voltar"
                variant="ghost"
                onPress={() => setStep(1)}
                style={styles.backButton}
              />
            </View>
          )}

          <Text style={styles.footnote}>
            Tudo fica salvo só no seu aparelho.
          </Text>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
  },
  flex: { flex: 1 },
  container: {
    flex: 1,
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.xxl,
    justifyContent: 'space-between',
  },
  header: {
    alignItems: 'center',
    marginTop: spacing.xl,
  },
  brand: {
    ...typography.displayLarge,
    color: colors.primary,
    marginBottom: spacing.sm,
  },
  subtitle: {
    ...typography.bodyMedium,
    color: colors.textSecondary,
    textAlign: 'center',
    paddingHorizontal: spacing.lg,
  },
  stepBox: {
    width: '100%',
  },
  question: {
    ...typography.heading,
    color: colors.textPrimary,
    marginBottom: spacing.md,
  },
  input: {
    ...typography.bodyLarge,
    color: colors.textPrimary,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radii.md,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.md,
    marginBottom: spacing.lg,
  },
  button: {
    width: '100%',
  },
  backButton: {
    marginTop: spacing.sm,
  },
  footnote: {
    ...typography.caption,
    color: colors.textMuted,
    textAlign: 'center',
    marginBottom: spacing.lg,
  },
});
