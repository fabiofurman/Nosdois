import React from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  Pressable,
  SafeAreaView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Card from '../components/Card';
import { colors } from '../theme/colors';
import { typography, spacing, radii } from '../theme/typography';
import { useProfile } from '../context/ProfileContext';

// Frases por dia da semana — 0=dom ... 6=sáb
const DAILY_PHRASES = [
  'Cuidar do "nós" também é cuidar do "eu".',
  'Pequenos gestos hoje constroem grandes histórias amanhã.',
  'Escutar é mais raro — e mais bonito — do que falar.',
  'Cada dia é uma chance nova de se aproximar.',
  'O afeto cresce no detalhe, não no discurso.',
  'Estar presente é o presente que ninguém esquece.',
  'Amor que dura é amor que se conversa.',
];

export default function HomeScreen({ navigation }) {
  const { profile } = useProfile();
  const dayIdx = new Date().getDay();
  const phrase = DAILY_PHRASES[dayIdx];

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView
        contentContainerStyle={styles.container}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <Text style={styles.greeting}>
            Olá, {profile?.userName || 'você'}
          </Text>
          <Text style={styles.subgreeting}>
            Que bom te ver por aqui hoje.
          </Text>
        </View>

        <Card highlighted style={styles.phraseCard}>
          <Text style={styles.phraseLabel}>Pensamento de hoje</Text>
          <Text style={styles.phraseText}>{phrase}</Text>
        </Card>

        <Pressable
          onPress={() => navigation.navigate('Comunicação')}
          style={({ pressed }) => [
            styles.featureCard,
            styles.featureFeatured,
            pressed && { opacity: 0.92 },
          ]}
          accessibilityRole="button"
        >
          <View style={styles.featureIconBox}>
            <Ionicons name="chatbubbles-outline" size={28} color={colors.primary} />
          </View>
          <View style={styles.featureContent}>
            <Text style={styles.featureTitle}>Comunicação Inteligente</Text>
            <Text style={styles.featureDesc}>
              Quando der vontade de mandar algo no impulso, escreva aqui antes.
            </Text>
          </View>
          <Ionicons name="chevron-forward" size={22} color={colors.textMuted} />
        </Pressable>

        <Text style={styles.sectionLabel}>Em breve</Text>

        <PlaceholderCard
          icon="handshake-outline"
          title="Acordos"
          description="Combine pequenas coisas que tornam a rotina mais leve."
        />
        <PlaceholderCard
          icon="heart-outline"
          title="Conexão"
          description="Rituais e momentos pra fortalecer o vínculo de vocês."
        />
        <PlaceholderCard
          icon="person-outline"
          title="Eu"
          description="Um espaço pra cuidar de você, individualmente."
        />

        <View style={{ height: spacing.xl }} />
      </ScrollView>
    </SafeAreaView>
  );
}

function PlaceholderCard({ icon, title, description }) {
  // Alguns ícones MaterialCommunity não existem no Ionicons; uso um fallback.
  const safeIcon = icon === 'handshake-outline' ? 'people-outline' : icon;
  return (
    <Card style={styles.featureCard}>
      <View style={styles.featureIconBox}>
        <Ionicons name={safeIcon} size={26} color={colors.textSecondary} />
      </View>
      <View style={styles.featureContent}>
        <View style={styles.titleRow}>
          <Text style={styles.featureTitle}>{title}</Text>
          <View style={styles.badge}>
            <Text style={styles.badgeText}>Em breve</Text>
          </View>
        </View>
        <Text style={styles.featureDesc}>{description}</Text>
      </View>
    </Card>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
  },
  container: {
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.lg,
  },
  header: {
    marginBottom: spacing.lg,
  },
  greeting: {
    ...typography.displayMedium,
    color: colors.textPrimary,
  },
  subgreeting: {
    ...typography.bodyMedium,
    color: colors.textSecondary,
    marginTop: spacing.xs,
  },
  phraseCard: {
    marginBottom: spacing.lg,
  },
  phraseLabel: {
    ...typography.caption,
    color: colors.primary,
    textTransform: 'uppercase',
    letterSpacing: 1,
    marginBottom: spacing.sm,
  },
  phraseText: {
    ...typography.bodyLarge,
    color: colors.textPrimary,
    fontStyle: 'italic',
  },
  featureCard: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.md,
    gap: spacing.md,
  },
  featureFeatured: {
    backgroundColor: colors.surface,
    borderRadius: radii.lg,
    padding: spacing.lg,
    borderWidth: 1,
    borderColor: colors.primarySoft,
  },
  featureIconBox: {
    width: 48,
    height: 48,
    borderRadius: radii.md,
    backgroundColor: colors.primaryWash,
    alignItems: 'center',
    justifyContent: 'center',
  },
  featureContent: {
    flex: 1,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginBottom: spacing.xs,
  },
  featureTitle: {
    ...typography.label,
    color: colors.textPrimary,
  },
  featureDesc: {
    ...typography.bodySmall,
    color: colors.textSecondary,
  },
  sectionLabel: {
    ...typography.caption,
    color: colors.textMuted,
    textTransform: 'uppercase',
    letterSpacing: 1,
    marginTop: spacing.lg,
    marginBottom: spacing.md,
  },
  badge: {
    backgroundColor: colors.surfaceMuted,
    paddingHorizontal: spacing.sm,
    paddingVertical: 2,
    borderRadius: radii.pill,
  },
  badgeText: {
    ...typography.caption,
    color: colors.textSecondary,
    fontSize: 11,
  },
});
