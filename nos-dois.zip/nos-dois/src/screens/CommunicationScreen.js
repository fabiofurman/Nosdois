import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  Pressable,
  Alert,
} from 'react-native';
import * as Clipboard from 'expo-clipboard';
import Constants from 'expo-constants';
import { Ionicons } from '@expo/vector-icons';
import Button from '../components/Button';
import Card from '../components/Card';
import { colors } from '../theme/colors';
import { typography, spacing, radii } from '../theme/typography';
import { reformulateMessage } from '../services/anthropic';
import { getHistory, addToHistory, clearHistory } from '../storage/storage';

// A chave vem da variável EXPO_PUBLIC_ANTHROPIC_API_KEY (ver .env / README).
// process.env funciona com o prefixo EXPO_PUBLIC_ no Expo SDK 49+.
const API_KEY = process.env.EXPO_PUBLIC_ANTHROPIC_API_KEY
  || Constants?.expoConfig?.extra?.anthropicApiKey
  || '';

export default function CommunicationScreen() {
  const [original, setOriginal] = useState('');
  const [reformulated, setReformulated] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [history, setHistory] = useState([]);
  const [showHistory, setShowHistory] = useState(false);
  const [copyFeedback, setCopyFeedback] = useState(false);

  useEffect(() => {
    (async () => {
      const h = await getHistory();
      setHistory(h);
    })();
  }, []);

  const runReformulation = useCallback(async (text) => {
    setLoading(true);
    setErrorMsg('');
    try {
      const result = await reformulateMessage(text, API_KEY);
      setReformulated(result);
      const entry = {
        id: `${Date.now()}`,
        original: text,
        reformulated: result,
        createdAt: new Date().toISOString(),
      };
      const updated = await addToHistory(entry);
      setHistory(updated);
    } catch (err) {
      setErrorMsg(err.message || 'Algo deu errado. Tente de novo.');
      setReformulated('');
    } finally {
      setLoading(false);
    }
  }, []);

  function handleSubmit() {
    if (!original.trim() || loading) return;
    runReformulation(original);
  }

  function handleRetry() {
    if (!original.trim() || loading) return;
    runReformulation(original);
  }

  async function handleCopy() {
    if (!reformulated) return;
    await Clipboard.setStringAsync(reformulated);
    setCopyFeedback(true);
    setTimeout(() => setCopyFeedback(false), 2000);
  }

  function handleClearHistory() {
    Alert.alert(
      'Apagar histórico?',
      'As últimas reformulações vão sumir do aparelho.',
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Apagar',
          style: 'destructive',
          onPress: async () => {
            await clearHistory();
            setHistory([]);
          },
        },
      ]
    );
  }

  function loadFromHistory(entry) {
    setOriginal(entry.original);
    setReformulated(entry.reformulated);
    setShowHistory(false);
    setErrorMsg('');
  }

  return (
    <SafeAreaView style={styles.safe}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        style={styles.flex}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 80 : 0}
      >
        <ScrollView
          contentContainerStyle={styles.container}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.header}>
            <Text style={styles.title}>Comunicação Inteligente</Text>
            <Text style={styles.subtitle}>
              Escreva sem se preocupar com o tom. A gente cuida disso juntos.
            </Text>
          </View>

          <Text style={styles.label}>O que está sentindo?</Text>
          <TextInput
            value={original}
            onChangeText={setOriginal}
            placeholder="Escreva o que está sentindo, sem filtro..."
            placeholderTextColor={colors.textMuted}
            style={styles.textarea}
            multiline
            textAlignVertical="top"
            accessibilityLabel="Campo para escrever sua mensagem"
          />

          <Button
            title="Reformular com cuidado"
            onPress={handleSubmit}
            loading={loading}
            disabled={!original.trim()}
            style={styles.primaryAction}
            icon={
              !loading && (
                <Ionicons name="sparkles-outline" size={18} color={colors.surface} />
              )
            }
          />

          {errorMsg ? (
            <Card style={styles.errorCard}>
              <View style={styles.errorRow}>
                <Ionicons name="alert-circle-outline" size={20} color={colors.error} />
                <Text style={styles.errorText}>{errorMsg}</Text>
              </View>
            </Card>
          ) : null}

          {reformulated ? (
            <Card highlighted style={styles.resultCard}>
              <Text style={styles.resultLabel}>Sugestão</Text>
              <Text style={styles.resultText}>{reformulated}</Text>

              <View style={styles.actionsRow}>
                <Button
                  title={copyFeedback ? 'Copiado!' : 'Copiar'}
                  variant="secondary"
                  onPress={handleCopy}
                  style={styles.actionBtn}
                  icon={
                    <Ionicons
                      name={copyFeedback ? 'checkmark' : 'copy-outline'}
                      size={18}
                      color={colors.primary}
                    />
                  }
                />
                <Button
                  title="Tentar de novo"
                  variant="ghost"
                  onPress={handleRetry}
                  loading={loading}
                  style={styles.actionBtn}
                  icon={
                    !loading && (
                      <Ionicons name="refresh-outline" size={18} color={colors.textSecondary} />
                    )
                  }
                />
              </View>
            </Card>
          ) : null}

          {history.length > 0 && (
            <View style={styles.historySection}>
              <Pressable
                onPress={() => setShowHistory((v) => !v)}
                style={styles.historyToggle}
                accessibilityRole="button"
              >
                <Text style={styles.historyToggleText}>
                  {showHistory ? 'Ocultar histórico' : `Ver últimas (${history.length})`}
                </Text>
                <Ionicons
                  name={showHistory ? 'chevron-up' : 'chevron-down'}
                  size={18}
                  color={colors.textSecondary}
                />
              </Pressable>

              {showHistory && (
                <View style={styles.historyList}>
                  {history.map((entry) => (
                    <Pressable
                      key={entry.id}
                      onPress={() => loadFromHistory(entry)}
                      style={({ pressed }) => [
                        styles.historyItem,
                        pressed && { opacity: 0.7 },
                      ]}
                    >
                      <Text style={styles.historyOriginal} numberOfLines={2}>
                        “{entry.original}”
                      </Text>
                      <Text style={styles.historyReformulated} numberOfLines={2}>
                        → {entry.reformulated}
                      </Text>
                    </Pressable>
                  ))}

                  <Pressable
                    onPress={handleClearHistory}
                    style={styles.clearButton}
                  >
                    <Text style={styles.clearText}>Apagar histórico</Text>
                  </Pressable>
                </View>
              )}
            </View>
          )}

          <View style={{ height: spacing.xxl }} />
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
  },
  flex: { flex: 1 },
  container: {
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.lg,
  },
  header: {
    marginBottom: spacing.lg,
  },
  title: {
    ...typography.displayMedium,
    color: colors.textPrimary,
  },
  subtitle: {
    ...typography.bodyMedium,
    color: colors.textSecondary,
    marginTop: spacing.xs,
  },
  label: {
    ...typography.label,
    color: colors.textPrimary,
    marginBottom: spacing.sm,
  },
  textarea: {
    ...typography.bodyLarge,
    color: colors.textPrimary,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radii.md,
    padding: spacing.md,
    minHeight: 140,
    marginBottom: spacing.md,
  },
  primaryAction: {
    marginBottom: spacing.lg,
  },
  errorCard: {
    backgroundColor: colors.errorWash,
    borderColor: colors.error,
    marginBottom: spacing.md,
  },
  errorRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  errorText: {
    ...typography.bodySmall,
    color: colors.textPrimary,
    flex: 1,
  },
  resultCard: {
    marginBottom: spacing.lg,
  },
  resultLabel: {
    ...typography.caption,
    color: colors.primary,
    textTransform: 'uppercase',
    letterSpacing: 1,
    marginBottom: spacing.sm,
  },
  resultText: {
    ...typography.bodyLarge,
    color: colors.textPrimary,
    marginBottom: spacing.lg,
  },
  actionsRow: {
    flexDirection: 'row',
    gap: spacing.sm,
  },
  actionBtn: {
    flex: 1,
    paddingHorizontal: spacing.md,
  },
  historySection: {
    marginTop: spacing.md,
  },
  historyToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: spacing.sm,
  },
  historyToggleText: {
    ...typography.bodyMedium,
    color: colors.textSecondary,
  },
  historyList: {
    marginTop: spacing.sm,
  },
  historyItem: {
    backgroundColor: colors.surface,
    borderRadius: radii.md,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.md,
    marginBottom: spacing.sm,
  },
  historyOriginal: {
    ...typography.bodySmall,
    color: colors.textSecondary,
    fontStyle: 'italic',
    marginBottom: spacing.xs,
  },
  historyReformulated: {
    ...typography.bodySmall,
    color: colors.textPrimary,
  },
  clearButton: {
    paddingVertical: spacing.md,
    alignItems: 'center',
  },
  clearText: {
    ...typography.caption,
    color: colors.textMuted,
  },
});
