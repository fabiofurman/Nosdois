import React from 'react';
import { View, ActivityIndicator, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';

import HomeScreen from '../screens/HomeScreen';
import CommunicationScreen from '../screens/CommunicationScreen';
import PlaceholderScreen from '../screens/PlaceholderScreen';
import OnboardingScreen from '../screens/OnboardingScreen';

import { useProfile } from '../context/ProfileContext';
import { colors } from '../theme/colors';
import { typography } from '../theme/typography';

const Tab = createBottomTabNavigator();

const ICONS = {
  Início: 'home-outline',
  Comunicação: 'chatbubbles-outline',
  Acordos: 'people-outline',
  Conexão: 'heart-outline',
  Eu: 'person-outline',
};

function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.textMuted,
        tabBarStyle: {
          backgroundColor: colors.surface,
          borderTopColor: colors.divider,
          borderTopWidth: 1,
          height: 64,
          paddingTop: 6,
          paddingBottom: 8,
        },
        tabBarLabelStyle: {
          ...typography.caption,
          fontSize: 12,
        },
        tabBarIcon: ({ color, size }) => (
          <Ionicons name={ICONS[route.name]} size={size} color={color} />
        ),
      })}
    >
      <Tab.Screen name="Início" component={HomeScreen} />
      <Tab.Screen name="Comunicação" component={CommunicationScreen} />
      <Tab.Screen
        name="Acordos"
        component={PlaceholderScreen}
        initialParams={{
          title: 'Acordos',
          description:
            'Combinados pequenos que fazem grande diferença na rotina de vocês.',
          icon: 'people-outline',
        }}
      />
      <Tab.Screen
        name="Conexão"
        component={PlaceholderScreen}
        initialParams={{
          title: 'Conexão',
          description:
            'Rituais e momentos pra fortalecer o vínculo de vocês, no seu ritmo.',
          icon: 'heart-outline',
        }}
      />
      <Tab.Screen
        name="Eu"
        component={PlaceholderScreen}
        initialParams={{
          title: 'Eu',
          description:
            'Um espaço pra cuidar de você. Porque o nós começa em cada um.',
          icon: 'person-outline',
        }}
      />
    </Tab.Navigator>
  );
}

export default function RootNavigator() {
  const { onboarded, loading } = useProfile();

  if (loading) {
    return (
      <View style={styles.loadingScreen}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <NavigationContainer>
      {onboarded ? <MainTabs /> : <OnboardingScreen />}
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  loadingScreen: {
    flex: 1,
    backgroundColor: colors.background,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
