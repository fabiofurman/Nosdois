import AsyncStorage from '@react-native-async-storage/async-storage';

const KEYS = {
  PROFILE: '@nosdois/profile',
  HISTORY: '@nosdois/reformulations',
  ONBOARDED: '@nosdois/onboarded',
};

const HISTORY_LIMIT = 10;

// ----- Perfil (nomes do casal) -----
export async function getProfile() {
  try {
    const raw = await AsyncStorage.getItem(KEYS.PROFILE);
    return raw ? JSON.parse(raw) : null;
  } catch (e) {
    console.warn('getProfile failed', e);
    return null;
  }
}

export async function saveProfile({ userName, partnerName }) {
  const profile = {
    userName: (userName || '').trim(),
    partnerName: (partnerName || '').trim(),
  };
  await AsyncStorage.setItem(KEYS.PROFILE, JSON.stringify(profile));
  await AsyncStorage.setItem(KEYS.ONBOARDED, 'true');
  return profile;
}

export async function isOnboarded() {
  try {
    const flag = await AsyncStorage.getItem(KEYS.ONBOARDED);
    return flag === 'true';
  } catch {
    return false;
  }
}

// ----- Histórico de reformulações -----
export async function getHistory() {
  try {
    const raw = await AsyncStorage.getItem(KEYS.HISTORY);
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    console.warn('getHistory failed', e);
    return [];
  }
}

export async function addToHistory(entry) {
  // entry: { id, original, reformulated, createdAt }
  const current = await getHistory();
  const next = [entry, ...current].slice(0, HISTORY_LIMIT);
  await AsyncStorage.setItem(KEYS.HISTORY, JSON.stringify(next));
  return next;
}

export async function clearHistory() {
  await AsyncStorage.removeItem(KEYS.HISTORY);
}
