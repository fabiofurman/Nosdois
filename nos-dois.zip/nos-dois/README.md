# Nós Dois

Um app mobile pra casais cuidarem do relacionamento com mais leveza. MVP focado em **Comunicação Inteligente com IA**: você escreve no impulso, a IA reformula com Comunicação Não-Violenta (CNV).

---

## Stack

- **React Native + Expo** (SDK 51)
- **React Navigation** (bottom tabs)
- **Anthropic API** — modelo Claude Haiku 4.5 (rápido e barato pra reformulação curta)
- **AsyncStorage** pra persistência local
- Design: tons rosé/bege, tipografia serif acolhedora, foco em acessibilidade (fonte mínima 16, contraste AA)

---

## Pré-requisitos

- **Node.js 18+** ([download](https://nodejs.org))
- **npm** (vem com o Node)
- Para rodar no celular: **Expo Go** instalado ([Android](https://play.google.com/store/apps/details?id=host.exp.exponent) | [iOS](https://apps.apple.com/app/expo-go/id982107779))
- Uma chave da **Anthropic API** ([criar aqui](https://console.anthropic.com/settings/keys))

---

## Instalação — passo a passo

### 1. Instalar dependências

Abra o terminal na pasta do projeto e rode:

```bash
npm install
```

Isso baixa todos os pacotes (pode demorar alguns minutos na primeira vez).

### 2. Configurar a chave da API Anthropic

Copie o arquivo de exemplo:

```bash
cp .env.example .env
```

Abra o arquivo `.env` (na raiz do projeto) e cole sua chave:

```
EXPO_PUBLIC_ANTHROPIC_API_KEY=sk-ant-api03-sua-chave-aqui
```

> **Importante:** o prefixo `EXPO_PUBLIC_` é o que faz o Expo expor a variável pro app. Não tire.

### 3. Rodar o app

```bash
npx expo start
```

Vai abrir um QR code no terminal. No celular:

- **Android:** abra o app Expo Go e escaneie o QR code.
- **iOS:** abra a câmera nativa do iPhone, aponta pro QR code, toque na notificação.

O app carrega no Expo Go. Mudanças no código aparecem na hora (hot reload).

---

## ⚠️ Aviso de segurança importante

Esta versão chama a API Anthropic **direto do app**, com a chave embutida via variável de ambiente. Isso é **aceitável pra desenvolvimento e uso pessoal seu**, mas **não é seguro pra distribuir publicamente** — qualquer pessoa que inspecionar o tráfego do app extrai sua chave e pode torrar seus créditos.

**Quando for publicar nas lojas (Play Store / App Store), faça assim:**

1. Crie um backend mínimo (Cloudflare Workers, Supabase Edge Functions, Vercel Functions — qualquer um serve, todos têm tier gratuito generoso pro seu volume).
2. O backend guarda a chave Anthropic e expõe um endpoint tipo `POST /reformular`.
3. No app, em `src/services/anthropic.js`, troque a `API_URL` pra apontar pro seu backend e remova o header `x-api-key`. Pronto.

Eu estruturei o serviço justamente pra essa migração ser de 5 minutos quando chegar a hora.

---

## Estrutura de pastas

```
nos-dois/
├── App.js                          # ponto de entrada
├── app.json                        # config Expo
├── babel.config.js
├── package.json
├── .env.example                    # modelo da chave
└── src/
    ├── components/
    │   ├── Button.js               # botão (primário / secundário / ghost)
    │   └── Card.js
    ├── context/
    │   └── ProfileContext.js       # estado global do perfil
    ├── navigation/
    │   └── RootNavigator.js        # tabs + lógica onboarding
    ├── screens/
    │   ├── OnboardingScreen.js     # 2 passos: nome + parceiro
    │   ├── HomeScreen.js           # saudação + frase do dia + cards
    │   ├── CommunicationScreen.js  # ⭐ tela funcional principal
    │   └── PlaceholderScreen.js    # "em breve" reutilizável
    ├── services/
    │   └── anthropic.js            # cliente da API
    ├── storage/
    │   └── storage.js              # wrapper AsyncStorage
    └── theme/
        ├── colors.js               # paleta rosé/bege
        └── typography.js           # tipografia + spacing + radii
```

---

## Como funciona a Comunicação Inteligente

1. Usuário escreve qualquer coisa, mesmo no impulso.
2. Toca em **"Reformular com cuidado"**.
3. O app envia a mensagem pra Anthropic API com um system prompt especializado em CNV.
4. A IA devolve uma versão usando a estrutura: *"Eu me sinto [emoção] quando [situação], e gostaria [pedido]."*
5. Usuário pode **copiar** pra mandar pro parceiro, ou **tentar de novo** pra outra versão.
6. Últimas 10 reformulações ficam salvas localmente — toque pra reabrir qualquer uma.

### Trocar o modelo

Em `src/services/anthropic.js`, altere a constante `MODEL`:

```js
// Padrão (rápido e barato — recomendado pra esse caso)
const MODEL = 'claude-haiku-4-5-20251001';

// Pra qualidade máxima (mais caro, ligeiramente mais lento)
const MODEL = 'claude-sonnet-4-6';
```

---

## Customização rápida

- **Paleta de cores:** `src/theme/colors.js`
- **Fontes e tamanhos:** `src/theme/typography.js`
- **Frases do dia (Home):** `src/screens/HomeScreen.js`, array `DAILY_PHRASES`
- **System prompt da IA:** `src/services/anthropic.js`, constante `SYSTEM_PROMPT`

---

## Próximos passos (pós-MVP)

- **Acordos**: lista compartilhada de combinados leves do casal
- **Conexão**: rituais semanais, perguntas profundas, momentos
- **Eu**: diário individual, check-in emocional
- Sincronização entre os dois aparelhos (precisaria de backend + auth)
- Tema escuro

---

## Resolvendo problemas comuns

**"Chave da API não configurada"**
Confira que o `.env` tá na raiz, com prefixo `EXPO_PUBLIC_` e que você reiniciou o `expo start` depois de criar o arquivo. Variáveis de ambiente só são lidas no boot.

**"Chave da API inválida"**
Confere em https://console.anthropic.com/settings/keys se a chave tá ativa e tem créditos.

**App trava ao abrir**
Limpa o cache: `npx expo start --clear`.

**Mudanças não aparecem**
Sacode o celular pra abrir o menu do dev e toque em "Reload". Ou pressione `r` no terminal.

---

Feito com cuidado. Se algo quebrar, abra issue ou avisa.
